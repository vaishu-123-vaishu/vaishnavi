import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Linkedin } from "lucide-react";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      {/* Header */}
      <header className="flex flex-col items-center text-center mb-10">
        <motion.img
          src="/your-photo.jpg"
          alt="Kuruva Vaishnavi"
          className="w-32 h-32 rounded-full shadow-lg mb-4"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        />
        <h1 className="text-3xl font-bold">Kuruva Vaishnavi</h1>
        <p className="text-gray-600">Programmer</p>
        <div className="flex gap-4 mt-3 flex-wrap">
          <a href="mailto:vaishnavikottela@gmail.com" className="text-blue-600">
            vaishnavikottela@gmail.com
          </a>
          <span>|</span>
          <a
            href="https://www.linkedin.com/in/kuruva-vaishnavi-030a4536a"
            target="_blank"
            className="flex items-center text-blue-700"
          >
            <Linkedin className="mr-1 h-4 w-4" /> LinkedIn
          </a>
        </div>
      </header>

      {/* Summary */}
      <Card className="mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Professional Summary</h2>
          <p>
            Skilled Core Java and Python developer with expertise in AWS
            services like EC2, S3, IAM, VPC, and databases such as RDS, MySQL,
            and MongoDB. Proficient in developing scalable, secure, and
            efficient cloud-based applications with hands-on experience
            deploying applications on AWS EC2 (e.g., brastia.com).
          </p>
        </CardContent>
      </Card>

      {/* Experience */}
      <Card className="mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Experience</h2>
          <p>
            <strong>Cloud Application Developer (Trainee)</strong> — Rooman
            Technologies Pvt Ltd (05/2025 - 07/2025)
          </p>
        </CardContent>
      </Card>

      {/* Education */}
      <Card className="mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Education</h2>
          <p>
            <strong>B.Tech / B.E.</strong> — St. John's College Of Engineering
            And Technology (03/2022 - Current)
          </p>
          <p>CGPA: 78.8%</p>
        </CardContent>
      </Card>

      {/* Skills */}
      <Card className="mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Technical Skills</h2>
          <ul className="list-disc list-inside space-y-1">
            <li>Java</li>
            <li>Python</li>
            <li>AWS (EC2, S3, IAM, VPC, RDS)</li>
            <li>MySQL, MongoDB</li>
            <li>HTML, CSS, JavaScript</li>
            <li>Git & GitHub</li>
          </ul>
        </CardContent>
      </Card>

      {/* Courses */}
      <Card className="mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Courses</h2>
          <ul className="list-disc list-inside space-y-1">
            <li>Cloud Application Developer Program</li>
            <li>AI Tools with Python (GenSpark, Kaggle, LetCode, etc.)</li>
          </ul>
        </CardContent>
      </Card>

      {/* Hobbies */}
      <Card className="mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Hobbies</h2>
          <p>Reading, Blogging, Drawing</p>
        </CardContent>
      </Card>

      {/* Languages */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Languages</h2>
          <ul className="list-disc list-inside space-y-1">
            <li>English</li>
            <li>Telugu</li>
            <li>Hindi</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
