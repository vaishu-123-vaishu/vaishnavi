# 🌐 Kuruva Vaishnavi - Portfolio Website

This is a personal **portfolio website** built with:

- **Next.js 14**
- **Tailwind CSS**
- **shadcn/ui** (for cards, buttons, etc.)
- **Framer Motion** (for animations)
- **Lucide Icons** (for LinkedIn icon)

---

## 🚀 Features
- Animated profile photo with smooth transition
- Professional Summary
- Work Experience
- Education
- Technical Skills
- Courses & Certifications
- Hobbies
- Languages
- Responsive design (works on mobile & desktop)

---

## 📦 Installation

```bash
# Clone repo
git clone https://github.com/YOUR_USERNAME/portfolio.git
cd portfolio

# Install dependencies
npm install

# Run development server
npm run dev
```

Visit 👉 [http://localhost:3000](http://localhost:3000)

---

## 📤 Deployment

You can deploy easily on **Vercel**:

1. Push this project to your GitHub.
2. Go to [Vercel](https://vercel.com).
3. Import your repo → Deploy.
4. Your portfolio will be live!

---

## 🖼️ Setup

- Replace `public/your-photo.jpg` with your own photo.
- Update your details in `src/app/page.js`.
